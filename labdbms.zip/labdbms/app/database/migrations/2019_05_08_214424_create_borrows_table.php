<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateBorrowsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('borrows', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('borrow_id',100);
            $table->bigInteger('sport_id')->unsigned();
            $table->bigInteger('userd_id')->unsigned();
            $table->integer('borrow_unit');
            $table->string('borrow_status',100);
            $table->foreign('sport_id')->references('id')->on('sports');
            $table->foreign('userd_id')->references('id')->on('users_detail');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('borrows');
    }
}
