@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                
                <div class="panel-heading">
                <form method="post" action="{{ route('addtype.update',$data->id) }}"> <!-- send data to function update in TypeController -->
                @csrf
                @method('PUT')
                <table class="table">
                    <tr>
                        <td><label for="type_id">รหัสอุปกรณ์</label></td>
                        <td><input type=text name="type_id" value="{{ $data->type_id }}"></td>
                    </tr>
                    <tr>
                        <td><label for="type_name">ชนิดอุปกรณ์</label></td>
                        <td><input type=text name="type_name" value="{{ $data->type_name}}"></td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">ยืนยัน</button>
                        </td>
                    </tr>
                   
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
