@extends('layouts.app')
<style>
    html,
    body {
        background-image: url("https://cdn.pixabay.com/photo/2017/06/14/16/57/background-2402709_960_720.jpg");
        background-color: #cccccc;
        height: 450px;
        background-repeat: no-repeat;
        background-size: cover;


    }
</style>
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">ระบบยืม-คืนอุปกรณ์กีฬา</div>

                <div class="card-body">
                    <a href="{{ route('addtype.index') }}" class="btn btn-outline-secondary" role="button">เพิ่มชนิดอุปกรณ์กีฬา</a>
                    <a href="{{ route('addsport.index') }}" class="btn btn-outline-secondary" role="button">เพิ่มอุปกรณ์กีฬา</a>
                    <a href="{{ route('addborrow.index') }}" class="btn btn-outline-secondary" role="button">การยืมอุปกรณ์กีฬา</a>
                    <a href="{{ route('adduser_detail.index') }}" class="btn btn-outline-secondary" role="button">เพิ่มข้อมูลผู้ยืม</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection