<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    img {
        display: block;
        margin-left: auto;
        margin-right: auto;
    }

    ,
</style>

<body>
    @if($data)
    @foreach($data as $row)
    <img src="{{ $row->sp_img}}" alt="Paris" class="center" width="500" height="500">
    <h1 style="text-align:center;"> {{ $row->sp_name}}</h1><br>
    <h1 style="text-align:center;">จำนวนคงเหลือ: {{ $row->sp_unit}}</h1>
    @endforeach
    @else
    ไม่พบข้อมูล
    @endif

</body>

</html>