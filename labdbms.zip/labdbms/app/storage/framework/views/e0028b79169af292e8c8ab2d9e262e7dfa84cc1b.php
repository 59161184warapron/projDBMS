

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">

                <div class="panel-heading">
                    <form method="post" action="<?php echo e(route('addborrow.update',$data->id)); ?>">
                        <!-- send data to function update in TypeController -->
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <table class="table">
                            <tr>
                                <td><label for="borrow_id">รหัสการยืม</label></td>
                                <td><input type=text name="borrow_id" disabled value="<?php echo e($data->borrow_id); ?>"></td>
                            </tr>
                            <tr>
                                <td><label for="userd_id">รหัสประจำตัวนิสิต</label></td>
                                <td><input type=text name="userd_id" disabled value="<?php echo e($data->userd_id); ?>"></td>

                            </tr>
                            <tr>
                                <td><label for="sport_id">ชื่ออุปกรณ์</label></td>
                                <td><input type=text name="sport_id" disabled value="<?php echo e($data->sport_id); ?>"></td>
                            </tr>
                            <tr>
                                <td><label for="borrow_unit">จำนวน</label></td>
                                <td><input type="text" name="borrow_unit" disabled value="<?php echo e($data->borrow_unit); ?>"><br></td>
                            </tr>
                            <tr>
                                <td><label for="borrow_status">สถานะ</label></td>
                                <td>
                                    <select name="borrow_status">
                                        <option value="ยืม">ยืม</option>
                                        <option value="คืน">คืน</option>
                                    </select>
                                </td>
                            </tr>

                            </tr>
                            <tr>
                                <td colspan=2 align=center>
                                    <button onclick="myFunction()" class="btn btn-success" id="demo" type="submit">ยืนยัน</button>
                                </td>
                            </tr>
                        </table>
                        <p id="demo"></p>
                        <script>
                            function myFunction() {
                                var txt;
                                var r = confirm("ยืนยัน");
                                if (r == true) {
                                    txt = "!";
                                } else {}
                                document.getElementById("demo").innerHTML = txt;
                            }
                        </script>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/addborrow/edit.blade.php */ ?>