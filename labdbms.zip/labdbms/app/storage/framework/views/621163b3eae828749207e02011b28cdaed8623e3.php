
<style>
    html,
    body {
        background-image: url("https://cdn.pixabay.com/photo/2017/06/14/16/57/background-2402709_960_720.jpg");
        background-color: #cccccc;
        height: 450px;
        background-repeat: no-repeat;
        background-size: cover;


    }
</style>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">ระบบยืม-คืนอุปกรณ์กีฬา</div>

                <div class="card-body">
                    <a href="<?php echo e(route('addtype.index')); ?>" class="btn btn-outline-secondary" role="button">เพิ่มชนิดอุปกรณ์กีฬา</a>
                    <a href="<?php echo e(route('addsport.index')); ?>" class="btn btn-outline-secondary" role="button">เพิ่มอุปกรณ์กีฬา</a>
                    <a href="<?php echo e(route('addborrow.index')); ?>" class="btn btn-outline-secondary" role="button">การยืมอุปกรณ์กีฬา</a>
                    <a href="<?php echo e(route('adduser_detail.index')); ?>" class="btn btn-outline-secondary" role="button">เพิ่มข้อมูลผู้ยืม</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/admin/dashboard.blade.php */ ?>