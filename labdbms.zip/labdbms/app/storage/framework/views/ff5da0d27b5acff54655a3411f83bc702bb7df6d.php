<style>
    div.panel-heading {
        text-align: center;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">

                    <?php if($data): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h1><?php echo e($row->sp_name); ?></h1><br>
                    <img src="<?php echo e($row->sp_img); ?>" width="500" height="500"><br></h1>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    ไม่พบข้อมูล
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /* /app/resources/views/addsport/search.blade.php */ ?>