

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <div>
                    <a href="<?php echo e(route('addsport.show',Auth::user()->id)); ?>" class="btn btn-outline-secondary" role="button">หน้าเพิ่มอุปกรณ์กีฬา</a>
                    </div>
                    <table class="table">
                        <thead>

                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">sp_id</th>
                                <th scope="col">sp_img</th>
                                <th scope="col">sp_name</th>
                                <th scope="col">sp_brand</th>
                                <th scope="col">sp_price</th>
                                <th scope="col">sp_buy</th>
                                <th scope="col">type_id</th>
                                <th scope="col" colspan=2>Operation</th>
                            </tr>
                        </thead>
                        <?php $i = 1; ?>
                        <?php if($data): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tbody>
                            <tr>
                                <th scope="row"><?php echo $i++; ?></th>
                                <td><?php echo e($row->sp_id); ?></td>
                                <td><img src="<?php echo e($row->sp_img); ?>" width="50" height="40"></td>
                                <td><?php echo e($row->sp_name); ?></td>
                                <td><?php echo e($row->sp_brand); ?></td>
                                <td><?php echo e($row->sp_price); ?></td>
                                <td><?php echo e($row->sp_buy); ?></td>
                                <td><?php echo e($row->type_id); ?></td>
                                <!-- route ไปที่ account and call function edit and update by . in file AccountController -->
                                <td><a href="<?php echo e(route('addsport.edit',$row->id)); ?>" class="btn btn-warning">Edit</a></td>
                                <!-- route ไปที่ account and call function destroy by . in file AccountController -->
                            </tr>

                        </tbody>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                        ไม่พบข้อมล
                        <?php endif; ?>
                    </table>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/addsport/showtable.blade.php */ ?>