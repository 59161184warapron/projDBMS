

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                
                <div class="panel-heading">
                <form method="post" action="<?php echo e(route('account.store')); ?>">
                <?php echo e(csrf_field()); ?>

                <table class="table">
                    <tr>
                        <td><label for="type_id">รหัสอุปกรณ์</label></td>
                        <td><input type=text name="type_id"></td>
                    </tr>
                    <tr>
                        <td><label for="sp_type">ชนิดอุปกรณ์</label></td>
                        <td><input type=text name="sp_type"></td>
                    </tr>
                    <tr>
                        <td colspan=2 align=center>
                        <button class="btn btn-success" type="submit">ยืนยัน</button>
                        </td>
                    </tr>
                   
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/account/create.blade.php */ ?>