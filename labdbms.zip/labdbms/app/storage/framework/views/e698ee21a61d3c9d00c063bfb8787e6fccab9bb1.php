

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div>
                    <a href="<?php echo e(route('account.create')); ?>" class="btn btn-success">เพิ่มชนิดอุปกรณ์</a>
                </div>

                <div class="panel-heading">
                
                <table class="table">
                    <thead>
                    
                        <tr>
                        <th scope="col">#</th>
                        <th scope="col">type_id</th>
                        <th scope="col">sp_type</th>
                        <th scope="col" colspan=2>Operation</th>
                        </tr>
                    </thead>
                    <?php $i=1; ?>
                    <?php $__currentLoopData = $account; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                        <th scope="row"><?php echo $i++; ?></th>
                        <td><?php echo e($row->type_id); ?></td>
                        <td><?php echo e($row->sp_type); ?></td>
                    <!-- route ไปที่ account and call function edit and update by . in file AccountController -->
                        <td><a href="<?php echo e(route('account.edit',$row->id)); ?>" class="btn btn-warning">Edit</a></td>
                    <!-- route ไปที่ account and call function destroy by . in file AccountController -->
                        <td><form method="post" action="<?php echo e(route('account.destroy',$row->id)); ?>" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button name="delete" 
                            type="Submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                        </tr>

                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* /app/resources/views/account/index.blade.php */ ?>