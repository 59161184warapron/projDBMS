<?php

namespace App\Http\Controllers;
// class db have method inset updae delete
use Illuminate\Http\Request;
use App\Returns;
use DB;

class ReturnController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //  insert into Transfer values('ACC001','ACC002','2019-05-02 14:00',500);
        DB::beginTransaction();
        $transfer = new Transfer;
        $request->validate(
            [
                'ACC_No_Source' => 'required|max:10',
                'ACC_No_Dest' => 'required|max:10',
                'Amount' => 'required'
            ]

        );
        $transfer->ACC_No_Source = $request->ACC_No_Source;
        $transfer->ACC_No_Dest = $request->ACC_No_Dest;
        $transfer->DateOp = date('Y-m-d H:i:s');
        $transfer->Amount = $request->Amount;
        $savetansfer = $transfer->save();

        $results = DB::select(
            'select Balance from Account where ACC_No=?',
            [$transfer->ACC_No_Source]
        );
        // ACC001 2000 < 500 balance

        if ($transfer->Amount <= $results[0]->Balance) {
            #$saveaccsrc = DB::update('update Account set Balance=Balance - ? where ACC_No=?',
            #[$transfer->Amount,$transfer->ACC_No_Source]);  # ? แทนค่าด้วยตัวแปล $transfer->Amount  ? ตัวที่สอง $transfer->ACC_No_Source
            $saveaccsrc = DB::update(
                'update Account set Balance=Balance - ? where ACC_No=?',
                [$transfer->Amount, $transfer->ACC_No_Source]
            );  # ? แทนค่าด้วยตัวแปล $transfer->Amount  ? ตัวที่สอง $transfer->ACC_No_Source
            $saveaccdest =  DB::update(
                'update Account set Balance=Balance + ? where ACC_No=?',
                [$transfer->Amount, $transfer->ACC_No_Dest]
            );  # ? แทนค่าด้วยตัวแปล $transfer->Amount  ? ตัวที่สอง $transfer->ACC_No_Source

            if ($savetansfer && $saveaccsrc && $saveaccdest) {
                DB::commit();
            } else {
                DB::rollback();
            }
        } else {
            
        }
        return redirect('account');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
      
    }
}
