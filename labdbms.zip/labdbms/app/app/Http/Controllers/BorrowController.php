<?php

namespace App\Http\Controllers;


use App\Borrow;
use App\Sport;
use Illuminate\Http\Request;
use DB;

class BorrowController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $data = DB::table('borrows')
            ->join('users_detail', 'users_detail.id', '=', 'borrows.userd_id')
            ->join('sports', 'sports.id', '=', 'borrows.sport_id')
            ->select('borrows.*', 'sports.sp_name', 'users_detail.userd_id')
            ->get();
        return view('addborrow.index', compact('data'));
        #return $data;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        $data = DB::table('borrows')->select('borrows.*')->get();
        $data2 = DB::table('users_detail')->select('users_detail.*')->get();
        $data3 = DB::table('sports')->select('sports.*')->get();
        return view('addborrow.create', compact('data', 'data2', 'data3'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $data = new Borrow;
        $request->validate(
            [
                'borrow_id' => 'required|max:100',
                'sport_id' => 'required|max:100',
                'userd_id' => 'required',
                'borrow_unit' => 'required',
                'borrow_status' => 'required',
            ]
        );
        $data->borrow_id = $request->borrow_id;
        $data->sport_id = $request->sport_id;
        $data->userd_id = $request->userd_id;
        $data->borrow_unit = $request->borrow_unit;
        $data->borrow_status = $request->borrow_status;
        $data->save();

        // $result = new Sport;
        $result = DB::select('select sp_unit from sports where id=?', [$data->sport_id]);

        if ($result[0]->sp_unit >= $data->borrow_unit) {
            $saveaccsrc = DB::update(
                'update sports set sp_unit=sp_unit - ? where id=?',
                [$data->borrow_unit, $data->sport_id]
            );  # ? แทนค่าด้วยตัวแปล $transfer->Amount  ? ตัวที่สอง $transfer->ACC_No_Source

            DB::commit();
        } else {
            DB::rollback();
        }
        return redirect('addborrow');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    { }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $data = Borrow::find($id); // same --> select * from account = id
       # $data2 = DB::table('users_detail')->select('users_detail.userd_id')->get();
       # $data3 = DB::table('sports')->select('sports.sp_name')->get();
        return view('addborrow.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $data = Borrow::find($id); // or Type::findOrFail
        $request->validate(
            [
                'borrow_status' => 'required|max:100'

            ]
        );
        $data->borrow_status = $request->borrow_status;
        $data->update();

        
        $result = DB::select('select sp_unit from sports where id=?', [$data->sport_id]);
        if ($result[0]->sp_unit >= $data->borrow_unit) {
            $saveaccsrc = DB::update(
                'update sports set sp_unit=sp_unit + ? where id=?',
                [$data->borrow_unit, $data->sport_id]
            );  # ? แทนค่าด้วยตัวแปล $transfer->Amount  ? ตัวที่สอง $transfer->ACC_No_Source
            DB::commit();
        } else {
            DB::rollback();
        }
        return redirect('addborrow');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        return redirect('addborrow');
    }
}
