<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Returns extends Model
{
    //
    protected $table = "returns";
    
    protected $fillable = [
        'No_Source',
        'No_Dest',
        'Amount'

    ];
}
